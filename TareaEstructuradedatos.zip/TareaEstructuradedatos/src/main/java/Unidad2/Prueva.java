
package Unidad2;

public class Prueva {
    
    public static void main(String args[]){
        TablasDeMultiplicar objeto = new TablasDeMultiplicar();
        System.out.print(objeto.TablaRecurcion(12, 10));
    }
}
