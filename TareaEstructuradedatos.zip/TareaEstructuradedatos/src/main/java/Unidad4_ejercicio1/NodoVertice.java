package Unidad4_ejercicio1;

public class NodoVertice {
    char dato;
    NodoVertice sig;
    NodoVertice ant;
    NodoArista arista;
    
    public NodoVertice(char d){
        this.dato = d;
        this.sig = this.ant = null;
        this.arista = null;
    }
    
    public boolean insertarArista(NodoVertice dirección){
        NodoArista nuevo = new NodoArista(dirección);
        if(nuevo == null) return false;
        
        if(arista == null){
            arista = nuevo;
            return true;
        }
        
        irUltino();
        arista.abajo = nuevo;
        nuevo.arriva = arista;
        return true;
    }

    private void irUltino(){
        while(arista.abajo != null){
            arista = arista.abajo;
        }
    }
    
    public void irPrimero(){
        while(arista.arriva != null){
            arista = arista.arriva;
        }
    }
    
    public NodoArista buscarArista(NodoVertice direccion){
        irPrimero();
        for(NodoArista buscar = arista; buscar != null; buscar = buscar.abajo){
            if(buscar.direccion == direccion){
                return buscar;
            }
        }
        return null;
    }
    
    private boolean unaSolaArista(){
        return arista.abajo == null && arista.arriva == null;
    }
    
    public boolean eliminarArista(NodoVertice direccion){
        if(arista == null) return false;
        NodoArista temp = buscarArista(direccion);
        
        if(temp == null) return false;
        if(temp == arista){
            if(unaSolaArista()) arista = null;
            else{
                arista = arista.abajo;
                temp.abajo.arriva = temp.abajo = null;
            }
            return true;
        }
        
        if(temp.abajo == null){
            temp.arriva.abajo = temp.arriva = null;
            return true;
        }
        
        temp.arriva.abajo = temp.abajo;
        temp.abajo.arriva = temp.arriva;
        temp.abajo = temp.arriva = null;
        return true;
    }
}
