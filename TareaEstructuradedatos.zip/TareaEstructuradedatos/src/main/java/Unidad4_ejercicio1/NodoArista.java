package Unidad4_ejercicio1;

public class NodoArista {
    
   NodoVertice direccion;
   NodoArista abajo;
   NodoArista arriva;
   
   public NodoArista(NodoVertice d){
       this.direccion = d;
       this.abajo = this.arriva = null;
   }
}
