package Unidad4_ejercicio1;

import javax.swing.JOptionPane;

public class InterfazGrafos extends javax.swing.JFrame {
    
    Grafo nuevo;
    String nodos;

    public InterfazGrafos() {
        initComponents();
        nuevo = new Grafo();
        nodos = "";
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonCrearVertices = new javax.swing.JButton();
        jButtonCrearAristas = new javax.swing.JButton();
        jButton3EliminarVertices = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton4EliminarAristas = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField3_Fin = new javax.swing.JTextField();
        jTextField3_Origen = new javax.swing.JTextField();
        jTextField2_Fin = new javax.swing.JTextField();
        jTextField2_Origen = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jButton5VerificarCamino = new javax.swing.JButton();
        jButton1MatrisA = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButtonCrearVertices.setText("CrearVertices");
        jButtonCrearVertices.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonCrearVerticesMouseClicked(evt);
            }
        });

        jButtonCrearAristas.setText("CrearAristas");
        jButtonCrearAristas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonCrearAristasMouseClicked(evt);
            }
        });

        jButton3EliminarVertices.setText("Eliminar Vertices");
        jButton3EliminarVertices.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3EliminarVerticesMouseClicked(evt);
            }
        });

        jLabel1.setText("Origen");

        jLabel2.setText("Fin");

        jLabel3.setText("Origen");

        jLabel4.setText("Fin");

        jButton4EliminarAristas.setText("EliminarAristas");
        jButton4EliminarAristas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4EliminarAristasMouseClicked(evt);
            }
        });

        jTextField3_Fin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3_FinActionPerformed(evt);
            }
        });

        jTextField3_Origen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3_OrigenActionPerformed(evt);
            }
        });

        jTextField2_Fin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2_FinActionPerformed(evt);
            }
        });

        jTextField2_Origen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2_OrigenActionPerformed(evt);
            }
        });

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jButton5VerificarCamino.setText("Verificar Camino");
        jButton5VerificarCamino.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5VerificarCaminoMouseClicked(evt);
            }
        });

        jButton1MatrisA.setText("Actualizar Matris de abyasencia");
        jButton1MatrisA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MatrisAMouseClicked(evt);
            }
        });
        jButton1MatrisA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1MatrisAActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1MatrisA)
                .addGap(62, 62, 62))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel3)
                        .addGap(47, 47, 47)
                        .addComponent(jLabel4)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 12, Short.MAX_VALUE)
                                .addComponent(jLabel1)
                                .addGap(46, 46, 46)
                                .addComponent(jLabel2)
                                .addGap(23, 23, 23))
                            .addComponent(jTextField7)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextField3_Origen, javax.swing.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                                    .addComponent(jTextField2_Origen))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField3_Fin)
                                    .addComponent(jTextField2_Fin))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jButtonCrearAristas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonCrearVertices, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jButton4EliminarAristas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton3EliminarVertices, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton5VerificarCamino, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(26, 26, 26))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonCrearVertices)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButtonCrearAristas)
                        .addComponent(jTextField2_Fin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField2_Origen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton4EliminarAristas)
                            .addComponent(jTextField3_Fin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField3_Origen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addComponent(jButton3EliminarVertices))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton5VerificarCamino))
                .addGap(18, 18, 18)
                .addComponent(jButton1MatrisA)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonCrearVerticesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonCrearVerticesMouseClicked
        nuevo.insertarDato(this.jTextField1.getText().charAt(0));
        nodos += this.jTextField1.getText().charAt(0) + "/";
        this.jTextField1.setText("");
    }//GEN-LAST:event_jButtonCrearVerticesMouseClicked

    private void jButtonCrearAristasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonCrearAristasMouseClicked
        char origen = this.jTextField2_Origen.getText().charAt(0);
        char fin = this.jTextField2_Fin.getText().charAt(0);
        this.jTextField2_Origen.setText("");
        this.jTextField2_Fin.setText("");
        boolean value = nuevo.insertarAristas(origen, fin);
        if(value == false){
            JOptionPane.showMessageDialog(this, "Error: valor o valores no existentes");
        }
    }//GEN-LAST:event_jButtonCrearAristasMouseClicked

    private void jButton4EliminarAristasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4EliminarAristasMouseClicked
        char origen = this.jTextField3_Origen.getText().charAt(0);
        char fin = this.jTextField3_Fin.getText().charAt(0);
        this.jTextField3_Origen.setText("");
        this.jTextField3_Fin.setText("");
        boolean value = nuevo.eliminarArista(origen, fin);
        if(value == false){
            JOptionPane.showMessageDialog(this, "Error: valor o valores no existentes");
        }
    }//GEN-LAST:event_jButton4EliminarAristasMouseClicked

    private void jButton3EliminarVerticesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3EliminarVerticesMouseClicked
        boolean value = nuevo.eliminarVertice(this.jTextField7.getText().charAt(0));
        this.jTextField7.setText("");
        if(value == false){
            JOptionPane.showMessageDialog(this, "Error: valor o valores no existentes");
        }
    }//GEN-LAST:event_jButton3EliminarVerticesMouseClicked

    private void jTextField3_OrigenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3_OrigenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3_OrigenActionPerformed

    private void jTextField2_FinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2_FinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2_FinActionPerformed

    private void jTextField3_FinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3_FinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3_FinActionPerformed

    private void jTextField2_OrigenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2_OrigenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2_OrigenActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jButton5VerificarCaminoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5VerificarCaminoMouseClicked
        boolean value = nuevo.VerificarCamino(this.jTextField3.getText(), nuevo);
        this.jTextField3.setText("");
        if(value == false){
            JOptionPane.showMessageDialog(this, "Camino Incorrecto");
        } else{
            JOptionPane.showMessageDialog(this, "Camino Correcto");
        }
    }//GEN-LAST:event_jButton5VerificarCaminoMouseClicked

    private void jButton1MatrisAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1MatrisAActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1MatrisAActionPerformed

    private void jButton1MatrisAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MatrisAMouseClicked
        nuevo.MatrisAdyacencia(nodos, nuevo);
        JOptionPane.showMessageDialog(this, nuevo.vectorToString());
    }//GEN-LAST:event_jButton1MatrisAMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(InterfazGrafos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new InterfazGrafos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1MatrisA;
    private javax.swing.JButton jButton3EliminarVertices;
    private javax.swing.JButton jButton4EliminarAristas;
    private javax.swing.JButton jButton5VerificarCamino;
    private javax.swing.JButton jButtonCrearAristas;
    private javax.swing.JButton jButtonCrearVertices;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2_Fin;
    private javax.swing.JTextField jTextField2_Origen;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField3_Fin;
    private javax.swing.JTextField jTextField3_Origen;
    private javax.swing.JTextField jTextField7;
    // End of variables declaration//GEN-END:variables
}
