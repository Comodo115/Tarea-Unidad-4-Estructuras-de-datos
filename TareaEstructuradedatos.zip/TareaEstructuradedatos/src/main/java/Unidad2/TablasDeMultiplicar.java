package Unidad2;

public class TablasDeMultiplicar {
    
    int a  = 1;
    double resul = 0;
    String tabla = ""; 
    
    // "num" es el numero de elementos 
    public String TablaRecurcion(int num, int base){       
        if(a <= base){
            resul += num;
            tabla += num + " x " + a + " = " + resul + "\n";
            a++;
            TablaRecurcion(num, base);
        }
        return tabla;
    }
}
