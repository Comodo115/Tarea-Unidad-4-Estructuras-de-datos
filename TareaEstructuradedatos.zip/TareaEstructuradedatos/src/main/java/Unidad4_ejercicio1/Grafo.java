package Unidad4_ejercicio1;

public class Grafo {
    NodoVertice vertice;
    int count;
    int[][] vector;
    
    public Grafo(){
        vertice = null;
        count = 0;
    }
    
    public boolean insertarDato(char dato){
        NodoVertice nuevo = new NodoVertice(dato);
        if(nuevo == null) return false;
        if(vertice == null){
            vertice = nuevo;
            count++;
            return true;
        }
        
        irUltimo();
        vertice.sig = nuevo;
        nuevo.ant = vertice;
        count++;
        return true;
    }

    private void irUltimo() {
        while(vertice.sig != null){
            vertice = vertice.sig;
        }
    }
    
    private void irPrimero() {
        while(vertice.ant != null){
            vertice = vertice.ant;
        }
    }
    
    private NodoVertice buscarVertice(char dato){
        if(vertice == null) return null;
        irPrimero();
        
        for(NodoVertice buscar = vertice; buscar != null; buscar = buscar.sig){
            if(buscar.dato == dato){
                return buscar;
            }
        }
        return null;
    }
    
    public boolean insertarAristas(char origen, char destino){
        NodoVertice nodoOrigen = buscarVertice(origen);
        NodoVertice nodoDestino = buscarVertice(destino);
        
        if(nodoOrigen == null || nodoDestino == null){
            return false;
        }
        
        return nodoOrigen.insertarArista(nodoDestino);
    }
    
    public boolean eliminarArista(char origen,char destino){
        NodoVertice nodoOrigen = buscarVertice(origen);
        NodoVertice nodoDestino = buscarVertice(destino);
        
        if(nodoOrigen == null || nodoDestino == null){
            return false;
        }
        
        count--;
        
        return nodoOrigen.eliminarArista(nodoDestino);
    }
    
    private boolean unSoloVertice(){
        return vertice.ant == null && vertice.sig == null;
    }
    
    public boolean eliminarVertice(char dato){
        if(vertice == null) return false;
        NodoVertice temp = buscarVertice(dato);
        if(temp == null) return false;
        if(temp.arista != null) return false;
        quitaAristaDeOtroVertice(temp);
        
        if(temp == vertice){
            if(unSoloVertice()) vertice = null;
            else{
                vertice = temp.sig;
                temp.sig.ant = temp.sig = null;
            }
            return true;
        }
        if(temp.sig == null){
            temp.ant.sig = temp.ant = null;
            return true;
        }
        temp.ant.sig = temp.sig;
        temp.sig.ant = temp.ant;
        temp.sig = temp.ant = null;
        return true;
    }

    private void quitaAristaDeOtroVertice(NodoVertice NodoEliminar) {
        irPrimero();
        for(NodoVertice buscar = vertice; buscar != null; buscar = buscar.sig){
            buscar.eliminarArista(NodoEliminar);
        }
    }
    
    public boolean VerificarCamino(String path, Grafo grafo){
        String[] vectorPath = path.split("/");
        
        for(int t1 = 0, t2 = 1; t2 > vectorPath.length -1; t1++, t2++){       
            NodoVertice nodoOrigen = buscarVertice(vectorPath[t1].charAt(0));
            NodoVertice nodoDestino = buscarVertice(vectorPath[t2].charAt(0));
            
            if(nodoOrigen == null || nodoDestino == null) return false;
            
            if(nodoOrigen.buscarArista(nodoDestino) == null) return false;
        }
        
        return true;
    }
    
    public boolean MatrisAdyacencia(String nodos, Grafo grafo){
        vector = new int[count][count];
        String[] vectorPath = nodos.split("/");
        
        for(int i = 0; i < count;i++){ 
            for(int j = 0; j < count; j++){
                vector[i][j] = 0;
            }
        }    
        
        for(int i = 0; i < count;i++){ 
            for(int j = 0; j < count; j++){
                NodoVertice nodoOrigen = buscarVertice(vectorPath[i].charAt(0));
                NodoVertice nodoDestino = buscarVertice(vectorPath[j].charAt(0));

                if(nodoOrigen == null || nodoDestino == null) return false;

                if(nodoOrigen.buscarArista(nodoDestino) == null){
                    vector[i][j] += 0;
                }else{
                    vector[i][j] += 1;
                }
            }
        }
        return true;
    }
    
    public String vectorToString(){
        String SVector = "";
        for(int i = 0; i < count;i++){ 
            for(int j = 0; j < count; j++){
                SVector += vector[i][j] + " ";
            }
            SVector += "\n";
        }
        return SVector;
    }      
}
